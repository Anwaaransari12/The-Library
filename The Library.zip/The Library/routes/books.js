const express = require('express');
const router = express.Router();
const Collections = require('../models/Collections');
const isLoggedIn = require('../middleware/isLoggedIn');
const passport = require('passport');
const catchAsync = require('../utils/catchAsync');
const User = require('../models/user');

router.get('/list', isLoggedIn, catchAsync(async (req, res) => {
    try {
        const developerId = '653accafa429d0d89974a3e3';
        const books = await Collections.find({});
        const currentUser = await User.findById(req.session.user_id);
        
        for (const book of books) {
            books.developer = developerId;
            await book.save();
        }
        console.log(currentUser.id.toString());
        console.log(books.developer);
        res.render('books/index', { books , currentUser });
    } catch (error) {
        console.error(error);
        res.status(500).render('Books/Error');
    }
}));

router.get('/home', (req, res) => {
    res.render('books/home.ejs')
})

router.get('/about', (req, res) => {
    res.render('books/about.ejs')
})

router.get('/new', isLoggedIn, (req, res) => {
    res.render('books/new');

})

router.post('/', isLoggedIn, async (req, res, next) => {
    try {
        const { title, developer, author, genre, description } = req.body;
        const newBook = new Collections({
            title,
            developer: '653accafa429d0d89974a3e3',
            author,
            genre,
            description
        });
        await newBook.save()
        console.log(newBook);

        if (!newBook) {
            return next(new Error('Details are incomplete.'));
        }
        res.redirect(`/books/list`);
    }
    catch (error) {
        next(res.status(401).render('Books/updateError'));
    }

})

router.get('/:id', catchAsync(async (req, res, next) => {
    try {
        const { id } = req.params;
        const books = await Collections.findById(id);

        if (!books) {
            return next(new Error('Book not found'));
        }

        console.log(books);
        res.render('Books/id', { books });
    } catch (error) {
        next(res.status(404).render('Books/Error'));
    }
}));

router.get('/:id/edit', isLoggedIn, async (req, res, next) => {
    try {
        const { id } = req.params;
        const EditBook = await Collections.findById(id);
        if (req.session.user_id !== EditBook.developer.toString()) {
            req.flash('error', '➤ You do not have Authority to do that !');
            return res.redirect(`/books/${id}`)
        }
        return res.render('Books/edit', { EditBook });
    }
    catch (error) {
        console.log(error)
        next(res.status(404).render('Books/alterError'));             
    }
})

router.put('/:id', catchAsync(async (req, res, next) => {
    try {
        const { id } = req.params;
        const books = await Collections.findById(id);
        if (req.session.user_id !== books.developer.toString()) {
            req.flash('error', '➤ You do not have Authority to do that !');
            return res.redirect(`/books/${id}`)
        }
        const updateBook = await Collections.findByIdAndUpdate(id, req.body, { runValidators: true, new: true })
        res.redirect(`/books/${updateBook._id}`)
    } catch (error) {
        next(res.status(401).render('Books/updateError'));


    }
}))

router.delete('/:id', isLoggedIn, catchAsync(async (req, res) => {
    const { id } = req.params;
    if (!req.session.user_id) {
        req.flash('error', '➤ File cant be deleted, Retry after login. ')
        res.redirect('users/login')
    }
    const DeleteBook = await Collections.findByIdAndDelete(id);
    res.redirect('/books/list')
}))

module.exports = router;