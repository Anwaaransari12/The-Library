const express = require('express');
const app = express();
const router = express.Router();
const User = require('../models/user');
const catchAsync = require('../utils/catchAsync');
const bcrypt = require('bcrypt');
const passport = require('passport');
const user = require('../models/user');
const path = require('path');
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'ejs');

router.get('/register', (req, res) => {
  res.render('users/register');
});
router.get('/login', (req, res) => {
  res.render('users/login');
})

router.post('/login', async (req, res) => {
  try {
    const { username, password } = req.body;
    const user = await User.findOne({ username });

    if (!user) {
      req.flash('incorrect', ' ➤ Incorrect username or password, please try again!');
      return res.redirect('/users/login');
    }

    const validPassword = await bcrypt.compare(password, user.password);

    if (validPassword) {
      req.session.user = {
        _id: user._id,
        username: user.username,
        email: user.email,
      };
      req.session.user_id = user._id;
      console.log('Session:', req.session);
      req.flash('success', '➤ Welcome back!');
      return res.redirect('/books/home');
    } else {
      req.flash('incorrect', ' ➤ Incorrect username or password, please try again!');
      return res.redirect('/users/login');
    }
  } catch (error) {
    console.error(error);
    res.status(500).send('Internal Server Error');
  }
});

router.post('/register', async (req, res) => {
  try {
    const { password, email, username } = req.body;
    const saltRounds = 12;
    const salt = await bcrypt.genSalt(saltRounds);
    const hash = await bcrypt.hash(password, salt);
    const newUser = new User({
      username,
      email,
      password: hash,
      salt,
    })
    console.log(newUser.username)
    req.session.user = {
      _id: user._id,
      username: user.username,
      email: user.email,
    };
    await newUser.save();
    console.log(newUser);
    req.session.user_id = newUser._id;
    return res.redirect('/books/home');
  } catch (error) {
    console.error(error);
    res.status(500).send('Internal Server Error');
  }
});

router.get('/logout', (req, res, next) => {
  req.logout(function (err) {
    if (err) {
      return next(err);
    }
    req.flash('success', '➤ Successfully logged out.');
    res.redirect('/books/home');
  });
});


module.exports = router;


