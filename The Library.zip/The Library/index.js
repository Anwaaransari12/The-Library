const express = require('express');
const app = express();
const path = require('path');
const mongoose = require('mongoose');
const methodOverride = require('method-override');
const Collections = require('./models/Collections');
const { error } = require('console');
const { nextTick } = require('process');
const { workerData } = require('worker_threads');
const passport = require('passport');
const LocalStrategy = require('passport-local');
const User = require('./models/user');
const session = require('express-session');
const flash = require('connect-flash');
const Bcrypt = require('bcrypt');

mongoose.connect('mongodb://127.0.0.1:27017/booksCollection', { useNewUrlParser: true, useUnifiedTopology: true })
  .then(() => {
    console.log("Mongoose connection worked!")
  })
  .catch((req, res) => {
    console.log("mongoose connection error.")
  });

app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'ejs');

app.use('/static', express.static("public"));
app.use(express.urlencoded({ extended: true }));
app.use(methodOverride('_method'));

const ExpressSession = {
  secret: 'your-secret-key',
  resave: false,
  saveUninitialized: true,
  cookie: {
    httpOnly: true,
    expires: Date.now() + 1000 * 60 * 60 * 24 * 7,
    maxAge: 1000 * 60 * 60 * 24 * 7
  }
}

app.use(session(ExpressSession));
app.use(flash());

app.use(passport.initialize());
app.use(passport.session());
passport.use(new LocalStrategy(User.authenticate()));

passport.serializeUser((user, done) => {
  done(null, user.id);
});

passport.deserializeUser((id, done) => {
  User.findById(id, (err, user) => {
    done(err, user);
  });
});

app.use((req, res, next) => {
  console.log(req.session.user_id);
  res.locals.currentUser = req.session.user;
  res.locals.incorrect = req.flash('incorrect')
  res.locals.success = req.flash('success')
  res.locals.error = req.flash('error')
  next();
})

const booksRoutes = require('./routes/books');
const userRoutes = require('./routes/users');
app.use('/books', booksRoutes);
app.use('/users', userRoutes);

app.use((req, res, next) => {
  res.status(404).render('books/error', { error: 'Not Found' });
});

app.use((err, req, res, next) => {
  console.log(err.stack);
  if (err.name === 'Error') {

    res.status(500).render('Books/intError', { error: 'Database error' });
  } else {
    next(err);
  }
});
app.listen(3000, () => {
  console.log("listening to port 3000!!");
})