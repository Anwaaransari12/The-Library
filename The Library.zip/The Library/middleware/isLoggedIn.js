module.exports = (req, res, next) => {
    console.log('reqUser...', req.session);
    if (!req.session.user_id) {
        req.flash('error', '➤ You must be Logged In to manipulate books.');
        res.redirect('/users/login');
    }
    next();
}
